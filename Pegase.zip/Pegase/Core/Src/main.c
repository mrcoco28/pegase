/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "max7219_Yncrea2.h"
#include "iks01a3_motion_sensors_ex.h"
#include "iks01a3_motion_sensors.h"
#include "iks01a3_env_sensors.h"
#include "iks01a3_env_sensors_ex.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define INSTANCE 0
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
int chronometreActif = 0;
char affichageTimer[5];
volatile int switch_HT = 1;
uint8_t flag_irq = 0;
int cpt = 0;
uint8_t tenth = 0;
uint8_t hundredth = 0;
uint8_t second = 0;
uint8_t ten_second = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM6_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */
void switchLed(void);
void switchLedAll(void);
void K2000(void);
void Chrono(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
char ISEN_Seq[]={'I','S','E','N'};

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	float myFloatfigure = 1.2;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_RTC_Init();
  MX_TIM6_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
  MAX7219_Init();
  if(IKS01A3_ENV_SENSOR_Init(INSTANCE, ENV_HUMIDITY)!= BSP_ERROR_NONE){
  	  printf("error init\n\r");
    }
    else{
  	  printf("capteur init\n\r");
    }
    if(IKS01A3_ENV_SENSOR_Init(INSTANCE, ENV_TEMPERATURE)!= BSP_ERROR_NONE){
    	  printf("error init\n\r");
  	}
  	else{
  	  printf("capteur init\n\r");
  	}
    if(IKS01A3_MOTION_SENSOR_Init(IKS01A3_LIS2DW12_0,MOTION_ACCELERO)!=BSP_ERROR_NONE){
    	printf("pb of accelerometer initialization\n\r");
    }else{
    	printf("LIS2DW12 accelerometer initialization\n\r");

    }
    IKS01A3_MOTION_SENSOR_SetFullScale(IKS01A3_LIS2DW12_0, MOTION_ACCELERO, 2);
    IKS01A3_MOTION_SENSOR_SetOutputDataRate(IKS01A3_LIS2DW12_0, MOTION_ACCELERO, 200.0);

    IKS01A3_MOTION_SENSOR_Axes_t accel_data;
    float temperature;
    float humidity;
    char humi_str[20];
    char temp_str[20];

  printf("Hello ITII P21 MRS my float: %1f\n\r", myFloatfigure);
  switchLedAll();
  MAX7219_DisplayTestStart();
  HAL_Delay(1000);
  switchLedAll();
  MAX7219_DisplayTestStop();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_TIM_Base_Start_IT(&htim6);
  printf("State:%x\r\n",HAL_TIM_Base_GetState(&htim6));

  while (1)
  {
	  void OpeningSequence(uint32_t MyDelay);
	  if (IKS01A3_MOTION_SENSOR_GetAxes(IKS01A3_LIS2DW12_0, MOTION_ACCELERO, &accel_data)== BSP_ERROR_NONE){
	 	  	  	printf("X: %ld, Y: %ld, Z:%ld\n\r",accel_data.x,accel_data.y,accel_data.z);
	 	  	  }else{
	 	  	  	printf("error reading LIS2DW12 data\n");
	 	  	  }
	  if(!HAL_GPIO_ReadPin(BTN1_GPIO_Port, BTN1_Pin)){
		  //switchLed();
		  //switchLedAll();
		  K2000();
		  printf("valeur chrono : %d \n\r", chronometreActif);

	  }

	  if(!HAL_GPIO_ReadPin(BTN2_GPIO_Port, BTN2_Pin)){
		  printf("Hello World\n\r");
		  if (IKS01A3_ENV_SENSOR_GetValue(INSTANCE, ENV_TEMPERATURE, &temperature) == BSP_ERROR_NONE)
		  			{
		  				sprintf(temp_str, "%.0f", temperature);
		  				printf("température : %s\n\r",temp_str);

		  					for (int i = 0; i < strlen(temp_str)+1; i++)
		  					{
		  					  MAX7219_DisplayChar(i+1,temp_str[i]);
		  					}
		  					MAX7219_DisplayChar(4,'C');

		  			}
	  }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  	  printf("test: %i\n\r",switch_HT);
	  	  if (IKS01A3_ENV_SENSOR_GetValue(INSTANCE, ENV_HUMIDITY, &humidity) == BSP_ERROR_NONE)
	  	  	{

	  	  		sprintf(humi_str, "%.0f", humidity);
	  	  		printf("humidité : %s\n\r",humi_str);
	  	  		if (switch_HT == 1)
	  	  		{
	  	  			for (int i = 0; i < strlen(humi_str)+1; i++)
	  	  			{
	  	  				MAX7219_DisplayChar(i+1,humi_str[i]);
	  	  			}
	  	  			MAX7219_DisplayChar(3,'H');
	  	  			MAX7219_DisplayChar(4,'U');
	  	  		}
	  	  	}
	  	  	if (IKS01A3_ENV_SENSOR_GetValue(INSTANCE, ENV_TEMPERATURE, &temperature) == BSP_ERROR_NONE)
	  	  	{
	  	  		sprintf(temp_str, "%.0f", temperature);
	  	  		printf("température : %s\n\r",temp_str);
	  	  		if (switch_HT == 0)
	  	  		{
	  	  			for (int i = 0; i < strlen(temp_str)+1; i++)
	  	  			{
	  	  			  MAX7219_DisplayChar(i+1,temp_str[i]);
	  	  			}
	  	  			MAX7219_DisplayChar(4,'C');
	  	  		}
	  	  	}
	  	  	HAL_Delay(1000);
	   }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLL_DIV3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 0x0;
  sTime.Minutes = 0x0;
  sTime.Seconds = 0x0;
  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  sDate.WeekDay = RTC_WEEKDAY_MONDAY;
  sDate.Month = RTC_MONTH_JANUARY;
  sDate.Date = 0x1;
  sDate.Year = 0x0;

  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 32000;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 1000;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, L0_Pin|L1_Pin|L2_Pin|L3_Pin
                          |L4_Pin|L5_Pin|L6_Pin|L7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : BTN4_Pin */
  GPIO_InitStruct.Pin = BTN4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BTN4_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : L0_Pin L1_Pin L2_Pin L3_Pin
                           L4_Pin L5_Pin L6_Pin L7_Pin */
  GPIO_InitStruct.Pin = L0_Pin|L1_Pin|L2_Pin|L3_Pin
                          |L4_Pin|L5_Pin|L6_Pin|L7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : BTN3_Pin */
  GPIO_InitStruct.Pin = BTN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BTN3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SPI_CS_Pin */
  GPIO_InitStruct.Pin = SPI_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SPI_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : BTN1_Pin BTN2_Pin */
  GPIO_InitStruct.Pin = BTN1_Pin|BTN2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
int __io_putchar(int ch){
	HAL_UART_Transmit(&huart2, (uint8_t*)&ch, 1, 0xFFFF);
	ITM_SendChar(ch);
	return ch;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	  chronometreActif++;
	  //printf("valeur chrono callbac: %d \r\n", chronometreActif);
	  Chrono();
  }
  void Chrono(void){
	  snprintf(affichageTimer, sizeof(affichageTimer), "%d", chronometreActif);
//	  for (int i = 0; i < strlen(affichageTimer)+1;) {
//	  MAX7219_DisplayChar(i+1,affichageTimer[i]);
//	 }
	  MAX7219_DisplayChar(1, affichageTimer[0]);//partie de l'affichage
	  MAX7219_DisplayChar(2, affichageTimer[1]);
	  MAX7219_DisplayChar(3, affichageTimer[2]);
	  MAX7219_DisplayChar(4, affichageTimer[3]);
  }


void switchLed(void){
	//HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
}

void switchLedAll(void){
	HAL_GPIO_TogglePin(L0_GPIO_Port, L0_Pin);
	HAL_GPIO_TogglePin(L1_GPIO_Port, L1_Pin);
	HAL_GPIO_TogglePin(L2_GPIO_Port, L2_Pin);
	HAL_GPIO_TogglePin(L3_GPIO_Port, L3_Pin);
	HAL_GPIO_TogglePin(L4_GPIO_Port, L4_Pin);
	HAL_GPIO_TogglePin(L5_GPIO_Port, L5_Pin);
	HAL_GPIO_TogglePin(L6_GPIO_Port, L6_Pin);
	HAL_GPIO_TogglePin(L7_GPIO_Port, L7_Pin);
}


void K2000(void){

	uint8_t i;
	uint16_t pinTab[8] = {L0_Pin, L1_Pin, L2_Pin, L3_Pin, L4_Pin, L5_Pin, L6_Pin, L7_Pin};

	// Turn on LEDs 0 to 7 progressively from left to right with a delay of 50ms
	for(i=7; i!=255; i--) // Changed i>0 to i!=255 to handle underflow of uint8_t
	{
		//printf ("%d \r\n", i+1); // Adjust print statement to match LED number
		HAL_GPIO_WritePin(L0_GPIO_Port, pinTab[i], GPIO_PIN_SET);
		HAL_Delay(50);
	}

	// Turn off LEDs 0 to 7 progressively from left to right with a delay of 50ms
	for(i=0; i<8; i++)
	{
		HAL_GPIO_WritePin(L0_GPIO_Port, pinTab[i], GPIO_PIN_RESET);
		HAL_Delay(50);
	}

	// Turn on LEDs 0 to 7 progressively from right to left with a delay of 50ms
	for(i=0; i<8; i++)
	{
		HAL_GPIO_WritePin(L0_GPIO_Port, pinTab[i], GPIO_PIN_SET);
		HAL_Delay(50);
	}

	// Turn off LEDs 0 to 7 progressively from right to left with a delay of 50ms
	for(i=7; i!=255; i--) // Again, changed i>0 to i!=255 to handle underflow
	{
		//printf ("%d \r\n", i+1); // Adjust print statement to match LED number
		HAL_GPIO_WritePin(L0_GPIO_Port, pinTab[i], GPIO_PIN_RESET);
		HAL_Delay(50);
	}
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
